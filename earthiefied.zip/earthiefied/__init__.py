"""Top-level package for earthiefied."""

__author__ = """Nimrod Ogoro"""
__email__ = "nimrodogoro@gmail.com"
__version__ = "0.0.1"
